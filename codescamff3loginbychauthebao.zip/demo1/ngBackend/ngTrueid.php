<?php 
  echo "HUY PLAY"; // Key Để Chạy 

/* Huy Play */
?>